This book intended for those who want to develop software using Qt5. If you want to improve 
the visual quality and content presentation of your software application, this book will suit 
you best.

Chapter 6, 7, 8, and 9 don't have code files.